﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RecipeApp.Interface;
using RecipeApp.Constants;

namespace RecipeApp.UnitTest
{
    [TestClass]
    public class RecipeFactoryTest
    {
        RecipeFactory factory;
        [TestInitialize]
        public void SetupMethod()
        {
             factory = new RecipeFactory();
        }

        [TestMethod]
        public void RecipeFactory_Implements_IfactoryInterface()
        {
            Assert.IsInstanceOfType(factory, typeof(IFactory<IRecipe, RecipeType>));
        }
        [TestMethod]
        public void RecipeFactory_NotImplements_OtherInterface()
        {
            Assert.IsNotInstanceOfType(factory, typeof(IRecipe));
        }

        [TestMethod]
        public void RecipeFactory_Factory_CreateRecipe1Instance()
        {
            var recipe = factory.Factory(RecipeType.Recipe1);
            Assert.IsInstanceOfType(recipe, typeof(Recipe1));
        }

        [TestMethod]
        public void RecipeFactory_Factory_NotCreateRecipe1Instance()
        {
            var recipe = factory.Factory(RecipeType.Recipe2);
            Assert.IsNotInstanceOfType(recipe, typeof(Recipe1));
        }

        [TestMethod]
        public void RecipeFactory_Factory_CreateRecipe2Instance()
        {
            var recipe = factory.Factory(RecipeType.Recipe2);
            Assert.IsInstanceOfType(recipe, typeof(Recipe2));
        }

        [TestMethod]
        public void RecipeFactory_Factory_NotCreateRecipe2Instance()
        {
            var recipe = factory.Factory(RecipeType.Recipe1);
            Assert.IsNotInstanceOfType(recipe, typeof(Recipe2));
        }

        [TestMethod]
        public void RecipeFactory_Factory_CreateRecipe3Instance()
        {
            var recipe = factory.Factory(RecipeType.Recipe3);
            Assert.IsInstanceOfType(recipe, typeof(Recipe3));
        }

        [TestMethod]
        public void RecipeFactory_Factory_NotCreateRecipe3Instance()
        {
            var recipe = factory.Factory(RecipeType.Recipe1);
            Assert.IsNotInstanceOfType(recipe, typeof(Recipe3));
        }

        [TestMethod]
        [ExpectedException(typeof(ApplicationException))]
        public void RecipeFactory_Factory_ExpectedException()
        {
            try
            {
                var recipe = factory.Factory(RecipeType.Recipe4);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        [TestMethod]
        public void RecipeFactory_Factory_NotExpectedException()
        {
            try
            {
                var recipe = factory.Factory(RecipeType.Recipe4);
            }
            catch (Exception ex)
            {
                Assert.AreNotEqual(ex, typeof(Exception));
            }
        }


    }
}
