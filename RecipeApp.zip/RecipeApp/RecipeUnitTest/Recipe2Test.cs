﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RecipeApp.Recipe;

namespace RecipeApp.UnitTest
{
    [TestClass]
    public class Recipe2Test
    {
        Recipe2 recipe2;
        [TestInitialize]
        public void SetupMethod()
        {
            recipe2 = new Recipe2(new SalesTax(), new Discount());

        }

        [TestMethod]
        public void recipe2_Implements_IRecipe()
        {
            Assert.IsInstanceOfType(recipe2, typeof(IRecipe));
        }

        [TestMethod]
        public void recipe2_Implements_BaseRecipe()
        {
            Assert.IsInstanceOfType(recipe2, typeof(BaseRecipe));
        }

        [TestMethod]
        public void recipe2_Implements_InjectsTaxInstance()
        {
            Assert.IsInstanceOfType(recipe2.SalesTax, typeof(SalesTax));
        }

        [TestMethod]
        public void recipe2_Implements_NotInjectsOtherThanTaxInstance()
        {
            Assert.IsNotInstanceOfType(recipe2.SalesTax, typeof(IRecipe));
        }

        [TestMethod]
        public void recipe2_Implements_InjectsDisCountInstance()
        {
            Assert.IsInstanceOfType(recipe2.WellnessDiscount, typeof(Discount));
        }

        [TestMethod]
        public void recipe2_Implements_NotInjectsOtherThanDiscountInstance()
        {
            Assert.IsNotInstanceOfType(recipe2.WellnessDiscount, typeof(IRecipe));
        }
    }
}
