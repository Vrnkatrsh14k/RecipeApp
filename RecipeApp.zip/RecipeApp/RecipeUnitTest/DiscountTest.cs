﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RecipeApp.Constants;
using System.Collections.Generic;

namespace RecipeApp.UnitTest
{
    [TestClass]
    public class DiscountTest
    {
        Discount Discount;
        [TestInitialize]
        public void SetupMethod()
        {
            Discount = new Discount();
        }
        [TestMethod]
        public void Discount_Implements_InterfaceIDiscount()
        {
            Assert.IsInstanceOfType(Discount, typeof(IDiscount));
        }

        [TestMethod]
        public void Discount_NotImplements_OtherInterface()
        {
            Assert.IsNotInstanceOfType(Discount, typeof(ITax));
        }

        [TestMethod]
        public void CalculateDiscount_WithoutOrganic_ExpectsZero()
        {
            var discount = Discount.CalculateDiscount(GetRecipeIngredientsWithoutOrganic());
            Assert.AreEqual(discount, 0);
        }

        [TestMethod]
        public void CalculateDiscount_Withorganic_ExpectsCents()
        {
            var discount = Discount.CalculateDiscount(GetRecipeIngredientsWithOrganic());
            Assert.AreEqual(discount, 0.04);
        }


        public List<IngredientModel> GetRecipeIngredientsWithoutOrganic()
        {
            return new List<IngredientModel>
            {
                new IngredientModel(){IngredientId =1 ,IngredientName = "Lemon", IngredientType= ProductType.Produce, Quantity = 1 },
                new IngredientModel(){IngredientId =1 ,IngredientName = "Salt", IngredientType= ProductType.Pantry, Quantity = Math.Round((decimal)3/4,2) },
                new IngredientModel(){IngredientId =1 ,IngredientName = "Pepper", IngredientType= ProductType.Pantry, Quantity = Math.Round((decimal)1/2,2) }
            };
        }
        public List<IngredientModel> GetRecipeIngredientsWithOrganic()
        {
            return new List<IngredientModel>
            {
                   new IngredientModel(){IngredientId =1 ,IngredientName = "GarlicClove", IngredientType= ProductType.Produce, Quantity = 1 , IsOrganic =true},
                    new IngredientModel(){IngredientId =1 ,IngredientName = "Corn", IngredientType= ProductType.Produce, Quantity = 4 },
                    new IngredientModel(){IngredientId =1 ,IngredientName = "Bacon", IngredientType= ProductType.Meat_Poultry, Quantity = 4 },
            };
        }
    }
}
