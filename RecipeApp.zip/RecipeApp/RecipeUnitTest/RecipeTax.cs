﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RecipeApp.Constants;
using System.Collections.Generic;

namespace RecipeApp.UnitTest
{
    [TestClass]
    public class RecipeTax
    {
        SalesTax Tax;
        [TestInitialize]
        public void SetupMethod()
        {
            Tax = new SalesTax();
        }
        [TestMethod]
        public void Discount_Implements_InterfaceIDiscount()
        {
            Assert.IsInstanceOfType(Tax, typeof(ITax ));
        }

        [TestMethod]
        public void Discount_NotImplements_OtherInterface()
        {
            Assert.IsNotInstanceOfType(Tax, typeof(IDiscount));
        }

        [TestMethod]
        public void CalculateDiscount_WithoutProduce_ExpectsCents()
        {
            double tax = Tax.CalculateTax(GetRecipeIngredientsWithoutProduce());
            Assert.AreEqual(tax, 0.07);
        }

        [TestMethod]
        public void CalculateDiscount_WithProduceAlone_ExpectsTaxZero()
        {
            double tax = Tax.CalculateTax(GetRecipeIngredientsWithProduceAlone());
            Assert.AreEqual(tax, 0);
        }
        [TestMethod]
        public void CalculateDiscount_WithProduce_ExpectsTaxCents()
        {
            double tax = Tax.CalculateTax(GetRecipeIngredientsWithProduce());
            Assert.AreEqual(Math.Round(tax,2), 0.35);
        }

        public List<IngredientModel> GetRecipeIngredientsWithProduceAlone()
        {
            return new List<IngredientModel>
            {
                new IngredientModel(){IngredientId =1 ,IngredientName = "Lemon", IngredientType= ProductType.Produce, Quantity = 2 },
            };
        }
        public List<IngredientModel> GetRecipeIngredientsWithoutProduce()
        {
            return new List<IngredientModel>
            {
               new IngredientModel(){IngredientId =1 ,IngredientName = "Bacon", IngredientType= ProductType.Meat_Poultry, Quantity = 1 },
               new IngredientModel(){IngredientId =1 ,IngredientName = "Pasta", IngredientType= ProductType.Pantry, Quantity = 1 },
            };
        }
        public List<IngredientModel> GetRecipeIngredientsWithProduce()
        {
            return new List<IngredientModel>
            {
                new IngredientModel(){IngredientId =1 ,IngredientName = "Lemon", IngredientType= ProductType.Produce, Quantity = 2 },
                new IngredientModel(){IngredientId =1 ,IngredientName = "OliveOil", IngredientType= ProductType.Pantry, Quantity = 2 }
                //new IngredientModel(){IngredientId =1 ,IngredientName = "Bacon", IngredientType= ProductType.Meat_Poultry, Quantity = 4 },
                //new IngredientModel(){IngredientId =1 ,IngredientName = "Pasta", IngredientType= ProductType.Pantry, Quantity = 8 },
            };
        }

    }
}
