﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RecipeApp.Interface;
using RecipeApp.Constants;
using RecipeApp.Recipe;
using System.Collections.Generic;

namespace RecipeApp.UnitTest
{
    [TestClass]
    public class Recipe1Test
    {
        Recipe1 recipe1;
        [TestInitialize]
        public void SetupMethod()
        {
            recipe1 = new Recipe1(new SalesTax(),new Discount());
        }

        [TestMethod]
        public void Recipe1_Implements_IRecipe()
        {
            Assert.IsInstanceOfType(recipe1, typeof(IRecipe));
        }

        [TestMethod]
        public void Recipe1_Implements_BaseRecipe()
        {
            Assert.IsInstanceOfType(recipe1, typeof(BaseRecipe));
        }

        [TestMethod]
        public void Recipe1_Implements_InjectsTaxInstance()
        {
            Assert.IsInstanceOfType(recipe1.SalesTax, typeof(SalesTax));
        }

        [TestMethod]
        public void Recipe1_Implements_NotInjectsOtherThanTaxInstance()
        {
            Assert.IsNotInstanceOfType(recipe1.SalesTax, typeof(IRecipe));
        }

        [TestMethod]
        public void Recipe1_Implements_InjectsDisCountInstance()
        {
            Assert.IsInstanceOfType(recipe1.WellnessDiscount, typeof(Discount));
        }

        [TestMethod]
        public void Recipe1_Implements_NotInjectsOtherThanDiscountInstance()
        {
            Assert.IsNotInstanceOfType(recipe1.WellnessDiscount, typeof(IRecipe));
        }


    }
}
