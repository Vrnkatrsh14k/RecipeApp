﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RecipeApp.Recipe;

namespace RecipeApp.UnitTest
{
    [TestClass]
    public class Recipe3Test
    {
        Recipe3 recipe3;
        [TestInitialize]
        public void SetupMethod()
        {
            recipe3 = new Recipe3(new SalesTax(), new Discount());

        }

        [TestMethod]
        public void recipe3_Implements_IRecipe()
        {
            Assert.IsInstanceOfType(recipe3, typeof(IRecipe));
        }

        [TestMethod]
        public void recipe3_Implements_BaseRecipe()
        {
            Assert.IsInstanceOfType(recipe3, typeof(BaseRecipe));
        }

        [TestMethod]
        public void recipe3_Implements_InjectsTaxInstance()
        {
            Assert.IsInstanceOfType(recipe3.SalesTax, typeof(SalesTax));
        }

        [TestMethod]
        public void recipe3_Implements_NotInjectsOtherThanTaxInstance()
        {
            Assert.IsNotInstanceOfType(recipe3.SalesTax, typeof(IRecipe));
        }

        [TestMethod]
        public void recipe3_Implements_InjectsDisCountInstance()
        {
            Assert.IsInstanceOfType(recipe3.WellnessDiscount, typeof(Discount));
        }

        [TestMethod]
        public void recipe3_Implements_NotInjectsOtherThanDiscountInstance()
        {
            Assert.IsNotInstanceOfType(recipe3.WellnessDiscount, typeof(IRecipe));
        }
    }
}
