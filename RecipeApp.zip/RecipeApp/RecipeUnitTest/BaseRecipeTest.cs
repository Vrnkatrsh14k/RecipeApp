﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RecipeApp.Recipe;
using RecipeApp.Constants;
using System.Collections.Generic;

namespace RecipeApp.UnitTest
{
    [TestClass]
    public class BaseRecipeTest
    {
        BaseRecipe recipe;

        [TestInitialize]
        public void SetupMethod()
        {
            recipe = new Recipe1(new SalesTax(), new Discount());
            recipe.Ingredients = GetRecipeIngredients();

        }
        [TestMethod]
        public void BaseRecipeTest_Implements_IRecipe()
        {
            Assert.IsInstanceOfType(recipe, typeof(IRecipe));
        }

        [TestMethod]
        public void CalculateTotal_NoSalestax_ExpectsTaxzero()
        {
            recipe = new Recipe1(null, new Discount());
            recipe.Ingredients = GetRecipeIngredients();
            recipe.CalculateTotal();
            Assert.AreEqual(recipe.Tax, 0);
        }

        [TestMethod]
        public void CalculateTotal_NoDiscount_ExpectsDiscountzero()
        {
            recipe = new Recipe1(new SalesTax(), null);
            recipe.Ingredients = GetRecipeIngredients();
            recipe.CalculateTotal();
            Assert.AreEqual(recipe.Discount, 0);
        }

        [TestMethod]
        [ExpectedException(typeof(ApplicationException))]
        public void CalculateTotal_NoIngredients_ExpectsException()
        {
            recipe = new Recipe1(new SalesTax(), null);
            recipe.Ingredients = null;
            recipe.CalculateTotal();
        }

        [TestMethod]
        public void CalculateTotal_WithIncludeTax_Expectscents()
        {
            recipe = new Recipe1(new SalesTax(), null);
            recipe.Ingredients = GetRecipeIngredients();
            recipe.CalculateTotal();
            Assert.AreEqual(recipe.Tax, 0.07);
        }

        [TestMethod]
        public void CalculateTotal_WithIncludeDisount_Expectscents()
        {
            recipe.CalculateTotal();
            Assert.AreEqual(recipe.Discount, 0.06);
        }
        [TestMethod]
        public void CalculateTotal_WithIngridents_Expectscents()
        {
            recipe.CalculateTotal();
            Assert.AreEqual(recipe.GrandTotal, 3.19);
        }
        [TestMethod]
        public void CalculateTotal_WithIngridentsNoTaxNoDiscount_Expectscents()
        {
            recipe = new Recipe1(null, null);
            recipe.Ingredients = GetRecipeIngredients();
            recipe.CalculateTotal();
            Assert.AreEqual(recipe.GrandTotal, 3.18);
        }



        public List<IngredientModel> GetRecipeIngredients()
        {
            return new List<IngredientModel>
            {
                new IngredientModel(){IngredientId =1 ,IngredientName = "GarlicClove", IngredientType= ProductType.Produce, Quantity = 1 , IsOrganic =true},
                new IngredientModel(){IngredientId =1 ,IngredientName = "Lemon", IngredientType= ProductType.Produce, Quantity = 1 },
                new IngredientModel(){IngredientId =1 ,IngredientName = "OliveOil", IngredientType= ProductType.Pantry, Quantity = Math.Round((decimal)1/4,2) }
                //new IngredientModel(){IngredientId =1 ,IngredientName = "Salt", IngredientType= ProductType.Pantry, Quantity = Math.Round((decimal)3/4,2) },
                //new IngredientModel(){IngredientId =1 ,IngredientName = "Pepper", IngredientType= ProductType.Pantry, Quantity = Math.Round((decimal)1/2,2) }
            };
        }

    }
}
