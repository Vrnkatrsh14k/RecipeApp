﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RecipeApp.Store;
using RecipeApp.Interface;
using RecipeApp.Constants;
namespace RecipeApp
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                IFactory<IRecipe, RecipeType> recipeFactory = new RecipeFactory();

                IRecipe recipe1 = recipeFactory.Factory(RecipeType.Recipe1);
                CalculateRecipePrice(recipe1);

                IRecipe recipe2 = recipeFactory.Factory(RecipeType.Recipe2);
                CalculateRecipePrice(recipe2);

                IRecipe recipe3 = recipeFactory.Factory(RecipeType.Recipe3);
                CalculateRecipePrice(recipe3);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.Write("\nPress any key to exit...");
            Console.ReadKey(true);

        }

        private static void CalculateRecipePrice(IRecipe recipe)
        {
            recipe.Ingredients = Recipestore.GetRecipeIngredients(recipe.RecipeName);
            recipe.CalculateTotal();
            DisplayRecipePrice(recipe);
        }

        private static void DisplayRecipePrice(IRecipe recipe)
        {
            Console.WriteLine(recipe.RecipeName);
            Console.WriteLine("Tax:{0}", recipe.Tax);
            Console.WriteLine("Discount:{0}", recipe.Discount);
            Console.WriteLine("GrandTotal:{0}", recipe.GrandTotal);
            Console.WriteLine("--------------------");
        }
    }
}
