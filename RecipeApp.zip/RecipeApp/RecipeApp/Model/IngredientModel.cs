﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RecipeApp.Store;
using RecipeApp.Constants;
namespace RecipeApp
{
    public class IngredientModel
    {
        public int IngredientId { get; set; }
        public string IngredientName { get; set; }
        public ProductType IngredientType { get; set; }
        public decimal Quantity { get; set; }
        public Measurements Measurement { get; set; }

        public double rate { get; set; }
        public double Rate
        {
            get
            {
                if (rate == 0)
                    rate = ((Recipestore.GetMasterIngredients().Where(x=>x.IngredientName == IngredientName).FirstOrDefault().Rate) * (double)this.Quantity);
                return rate;
            }
            set
            {
                rate = value;
            }
        }

        private bool isNotTaxable { get; set; }
        public bool IsNotTaxable
        {
            get
            {
                if (this.IngredientType == ProductType.Produce)
                    isNotTaxable = true;
                return isNotTaxable;
            }
        }

        private bool? isOrganic { get; set; }
        public  bool? IsOrganic
        {
            get
            {
                if (!isOrganic.HasValue)
                    isOrganic = Recipestore.GetMasterIngredients().Where(x => x.IngredientName == this.IngredientName).FirstOrDefault().isOrganic;
                return isOrganic;
            }
            set
            {
                isOrganic = value;
            }
        }
    }

  
}
