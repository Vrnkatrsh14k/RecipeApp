﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeApp.Utility
{
    public static class Utility
    {
        public static double NearestCent(this double value, double nearestcent)
        {
            return Math.Ceiling((value / (double)nearestcent)) * nearestcent;
        }

        public static double Calculate(this List<IngredientModel> Ingredients, Func<IngredientModel,bool> whereFunc, double percentage)
        {
            return (Ingredients.Where(whereFunc).Select(x => x.Rate).Sum()) * ((percentage / 100));
        }

        public static double Sum(this List<IngredientModel> Ingredients)
        {
            return Ingredients.Select(x => x.Rate).Sum();
        }
    }
}
