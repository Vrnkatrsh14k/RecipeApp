﻿using System.Collections.Generic;
namespace RecipeApp
{
    public interface ITax
    {
        double CalculateTax(List<IngredientModel> Ingredient);
    }
}