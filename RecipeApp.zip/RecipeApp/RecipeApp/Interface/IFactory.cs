﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RecipeApp.Constants;
namespace RecipeApp.Interface
{
    public interface IFactory<T,U>
    {
        T Factory(U Name);
    }
}
