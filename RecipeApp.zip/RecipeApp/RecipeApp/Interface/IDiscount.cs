﻿using System.Collections.Generic;

namespace RecipeApp
{
    public interface IDiscount
    {
        double CalculateDiscount(List<IngredientModel> Ingredient);
    }
}