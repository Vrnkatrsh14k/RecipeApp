﻿using RecipeApp.Constants;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeApp
{
    public interface IRecipe
    {
        RecipeType RecipeName { get; set; }
        List<IngredientModel> Ingredients { get; set; }
        double GrandTotal { get; set; }
        double Discount { get; set; }
        double Tax { get; set; }
        void CalculateTotal();



    }
}
