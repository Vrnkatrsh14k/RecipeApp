﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RecipeApp.Interface;
using RecipeApp.Constants;
namespace RecipeApp
{
    public class RecipeFactory : IFactory<IRecipe,RecipeType>
    {
        public IRecipe Factory(RecipeType recipe)
        {
            switch (recipe)
            {
                case RecipeType.Recipe1:
                    return new Recipe1(new SalesTax(), new Discount());
                case RecipeType.Recipe2:
                    return new Recipe2(new SalesTax(), new Discount());
                case RecipeType.Recipe3:
                    return new Recipe3(new SalesTax(), new Discount());
                default:
                    throw new ApplicationException(string.Format("This type of recipe can not be created"));
            }
        }

    }

}
