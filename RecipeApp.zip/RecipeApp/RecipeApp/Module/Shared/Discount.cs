﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RecipeApp.Constants;
using RecipeApp.Utility;
namespace RecipeApp
{
    public class Discount : IDiscount
    {
        private double discountpercentage;
        private double nearestcent;
        public double CalculateDiscount(List<IngredientModel> Ingredients)
        {
            discountpercentage = RecipeConstants.wellnessDiscount;
            nearestcent = RecipeConstants.nearestCent;
            return Ingredients.Calculate(whereDisountFunc, discountpercentage).NearestCent(nearestcent);
        }

        Func<IngredientModel, bool> whereDisountFunc = item => item.IsOrganic.HasValue && item.IsOrganic.Value;
    }
}
