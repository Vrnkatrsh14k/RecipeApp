﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RecipeApp.Constants;
using RecipeApp.Utility;
namespace RecipeApp
{
    public class SalesTax : ITax
    {
        private double taxpercentage;
        private double nearestcent;
        public double CalculateTax(List<IngredientModel> Ingredients)
        {
            taxpercentage = RecipeConstants.salestax;
            nearestcent = RecipeConstants.nearestCentTax;
            var ss = Ingredients.Calculate(whereTaxFunc, taxpercentage).NearestCent(nearestcent);
            return Ingredients.Calculate(whereTaxFunc, taxpercentage).NearestCent(nearestcent);
        }

        Func<IngredientModel, bool> whereTaxFunc = item => item.IsNotTaxable == false;
    }
}
