﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RecipeApp.Recipe;
using RecipeApp.Interface;
using RecipeApp.Constants;

namespace RecipeApp
{
    public class Recipe2 : BaseRecipe
    {

        public Recipe2(ITax tax, IDiscount discount) : base(tax, discount)
        {
            RecipeName = RecipeType.Recipe2;
        }

        //public override void CalculateTotal()
        //{

        //}
    }
}