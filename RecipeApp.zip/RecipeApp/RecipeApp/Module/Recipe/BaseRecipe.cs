﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RecipeApp.Utility;
using RecipeApp.Constants;
namespace RecipeApp.Recipe
{
    public class BaseRecipe : IRecipe
    {
        public RecipeType RecipeName { get; set; }
        public List<IngredientModel> Ingredients { get; set; }
        public double GrandTotal { get; set; }
        public double Discount { get; set; }
        public double Tax { get; set; }

        public ITax SalesTax;
        public IDiscount WellnessDiscount;

        public BaseRecipe(ITax tax, IDiscount discount)
        {
            SalesTax = tax;
            WellnessDiscount = discount;
        }

        public BaseRecipe()
        {

        }

        public virtual void CalculateTotal()
        {
            try
            {
                if (Ingredients != null && Ingredients.Count() > 0)
                {
                    if (WellnessDiscount != null)
                        Discount = WellnessDiscount.CalculateDiscount(Ingredients);
                    if (SalesTax != null)
                        Tax = SalesTax.CalculateTax(Ingredients);

                    GrandTotal = (Ingredients.Sum() + Tax - Discount).NearestCent(RecipeConstants.nearestCent);
                }
                else
                {
                    //Console.WriteLine("Ingredients are not avilable for {0}", RecipeName);
                    throw new ApplicationException(string.Format("Ingredients are not avilable for {0}", RecipeName));
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

    }
}
