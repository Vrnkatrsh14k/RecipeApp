﻿using System;
using System.Collections.Generic;
using RecipeApp.Recipe;
using RecipeApp.Constants;

namespace RecipeApp
{
    public class Recipe3 : BaseRecipe
    {
        public Recipe3(ITax tax, IDiscount discount) : base(tax, discount)
        {
            RecipeName = RecipeType.Recipe3;
        }

    }
}