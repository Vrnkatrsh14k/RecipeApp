﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RecipeApp.Constants;
namespace RecipeApp.Store
{
    public static class Recipestore
    {
        public static List<IngredientModel> GetMasterIngredients()
        {
            List<IngredientModel> Ingredients = new List<IngredientModel>
            {
                new IngredientModel(){IngredientId =1 ,IngredientName = "GarlicClove", IngredientType= ProductType.Produce, Quantity = 1 , Rate = 0.67 ,Measurement = Measurements.Unit, IsOrganic =true},
                new IngredientModel(){IngredientId =1 ,IngredientName = "Lemon", IngredientType= ProductType.Produce, Quantity = 1, Rate = 2.03, Measurement = Measurements.Unit,},
                new IngredientModel(){IngredientId =1 ,IngredientName = "Corn", IngredientType= ProductType.Produce, Quantity = 1, Rate =  0.87, Measurement = Measurements.Cup },

                new IngredientModel(){IngredientId =1 ,IngredientName = "ChickenBreast", IngredientType= ProductType.Meat_Poultry, Quantity = 1, Rate = 2.19,Measurement = Measurements.Unit},
                new IngredientModel(){IngredientId =1 ,IngredientName = "Bacon", IngredientType= ProductType.Meat_Poultry, Quantity = 1 , Rate = 0.24, Measurement = Measurements.Slice },

                new IngredientModel(){IngredientId =1 ,IngredientName = "Pasta", IngredientType= ProductType.Pantry, Quantity = 1, Rate=0.31, Measurement = Measurements.Ounce  },
                new IngredientModel(){IngredientId =1 ,IngredientName = "OliveOil", IngredientType= ProductType.Pantry, Quantity = 1, Rate = 1.92, Measurement =Measurements.Cup , IsOrganic =true},
                new IngredientModel(){IngredientId =1 ,IngredientName = "Vinegar", IngredientType= ProductType.Pantry, Quantity = 1, Rate = 1.26, Measurement =Measurements.Cup},
                new IngredientModel(){IngredientId =1 ,IngredientName = "Salt", IngredientType= ProductType.Pantry, Quantity = 1, Rate = 0.16, Measurement = Measurements.Teaspoon},
                new IngredientModel(){IngredientId =1 ,IngredientName = "Pepper", IngredientType= ProductType.Pantry, Quantity = 1, Rate=0.17 , Measurement = Measurements.Teaspoon }
            };
            return Ingredients;
        }
        public static List<IngredientModel> GetRecipeIngredients(RecipeType recipeName)
        {
            List<IngredientModel> Ingredients = null;
            switch (recipeName)
            {
                case RecipeType.Recipe1:
                    Ingredients = new List<IngredientModel>
                    {
                        new IngredientModel(){IngredientId =1 ,IngredientName = "GarlicClove", IngredientType= ProductType.Produce, Quantity = 1 , IsOrganic =true},
                        new IngredientModel(){IngredientId =1 ,IngredientName = "Lemon", IngredientType= ProductType.Produce, Quantity = 1 },
                        new IngredientModel(){IngredientId =1 ,IngredientName = "OliveOil", IngredientType= ProductType.Pantry, Quantity = Math.Round((decimal)3/4,2) },
                        new IngredientModel(){IngredientId =1 ,IngredientName = "Salt", IngredientType= ProductType.Pantry, Quantity = Math.Round((decimal)3/4,2) },
                        new IngredientModel(){IngredientId =1 ,IngredientName = "Pepper", IngredientType= ProductType.Pantry, Quantity = Math.Round((decimal)1/2,2) }
                    };
                    break;
                case RecipeType.Recipe2:
                    Ingredients = new List<IngredientModel>
                  {
                    new IngredientModel(){IngredientId =1 ,IngredientName = "GarlicClove", IngredientType= ProductType.Produce, Quantity = 1 , IsOrganic =true},
                    new IngredientModel(){IngredientId =1 ,IngredientName = "ChickenBreast", IngredientType= ProductType.Meat_Poultry, Quantity = 4 },
                    new IngredientModel(){IngredientId =1 ,IngredientName = "OliveOil", IngredientType= ProductType.Pantry, Quantity = Math.Round((decimal)1/2,2) },
                    new IngredientModel(){IngredientId =1 ,IngredientName = "Vinegar", IngredientType= ProductType.Pantry, Quantity = Math.Round((decimal)1/2, 2) }
                  };
                    break;
                case RecipeType.Recipe3:
                    Ingredients = new List<IngredientModel>
                  {
                    new IngredientModel(){IngredientId =1 ,IngredientName = "GarlicClove", IngredientType= ProductType.Produce, Quantity = 1 , IsOrganic =true},
                    new IngredientModel(){IngredientId =1 ,IngredientName = "Corn", IngredientType= ProductType.Produce, Quantity = 4 },
                    new IngredientModel(){IngredientId =1 ,IngredientName = "Bacon", IngredientType= ProductType.Meat_Poultry, Quantity = 4 },
                    new IngredientModel(){IngredientId =1 ,IngredientName = "Pasta", IngredientType= ProductType.Pantry, Quantity = 8 },
                    new IngredientModel(){IngredientId =1 ,IngredientName = "OliveOil", IngredientType= ProductType.Pantry, Quantity =Math.Round((decimal)1/3,2) },
                    new IngredientModel(){IngredientId =1 ,IngredientName = "Salt", IngredientType= ProductType.Pantry, Quantity =Math.Round((decimal)5/4,2) },
                    new IngredientModel(){IngredientId =1 ,IngredientName = "Pepper", IngredientType= ProductType.Pantry, Quantity =Math.Round((decimal)3/4,2) }
                  };
                    break;
                default:
                    break;
            }
            return Ingredients;
        }

        
    }


}
