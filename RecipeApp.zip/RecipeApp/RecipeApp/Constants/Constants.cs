﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeApp.Constants
{
    public enum Measurements
    {
        Unit,
        Cup,
        Ounce,
        Teaspoon,
        Slice
    }

    public enum ProductType
    {
        Produce,
        Meat_Poultry,
        Pantry
    }

    public enum RecipeType
    {
        Recipe1,
        Recipe2,
        Recipe3,
        Recipe4,
    }
    public static class RecipeConstants
    {
        public static readonly double salestax = 8.6;
        public static readonly double wellnessDiscount= 5;
        public static readonly double nearestCent =0.01;
        public static readonly double nearestCentTax = 0.07;
    }

}
